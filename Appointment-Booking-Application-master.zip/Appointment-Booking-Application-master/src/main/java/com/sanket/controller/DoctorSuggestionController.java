package com.sanket.controller;

import com.sanket.entity.Doctor;
import com.sanket.entity.Patient;
import com.sanket.exception.DoctorException;
import com.sanket.service.DoctorService;
import com.sanket.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import java.util.List;

@RestController
@RequestMapping("/suggested-doctors")
public class DoctorSuggestionController {

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private PatientService patientService; // Inject PatientService

    @GetMapping("/suggest")
    public ResponseEntity<Object> suggestDoctors(@RequestParam Long patientId) {
        // Fetch patient information, including location and symptom
        Patient patient = patientService.getPatientInfo(patientId); // Use the injected PatientService

        if (patient == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Patient not found with ID: " + patientId);
        }

        // Assuming you have a method in DoctorService to get doctors by location and speciality
        List<Doctor> suggestedDoctors = doctorService.getSuggestedDoctors(patient.getLocation(), patient.getSymptom());

        if (suggestedDoctors.isEmpty()) {
            if (!isLocationSupported(patient.getLocation())) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("We are still waiting to expand to your location");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("There isn't any doctor present at your location for your symptom");
            }
        }

        return ResponseEntity.ok(suggestedDoctors);
    }

    // You can implement this method to check if the location is supported (Delhi, Noida, Faridabad)
    private boolean isLocationSupported(String location) {
        return List.of("Delhi", "Noida", "Faridabad").contains(location);
    }
}
