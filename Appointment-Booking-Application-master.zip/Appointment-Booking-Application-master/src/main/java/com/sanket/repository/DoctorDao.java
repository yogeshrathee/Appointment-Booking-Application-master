package com.sanket.repository;

import org.h2.mvstore.Page;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.sanket.entity.Doctor;
import com.sanket.entity.Patient;

import java.awt.print.Pageable;
import java.util.List;

public interface DoctorDao extends JpaRepository<Doctor, Integer> {
	
	public Doctor findByMobileNo(String mobileNo);


}
