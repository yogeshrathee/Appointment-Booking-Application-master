package com.sanket.exception;

public class PatientException extends Exception {
	
	public PatientException() {
	
	}
	
	public PatientException(String msg) {
		super(msg);
	}
}
