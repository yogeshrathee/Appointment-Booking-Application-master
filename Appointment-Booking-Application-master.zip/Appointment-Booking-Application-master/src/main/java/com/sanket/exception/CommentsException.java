package com.sanket.exception;

public class CommentsException extends Exception {
	
	public CommentsException() {
	
	}
	
	public CommentsException(String msg) {
		super(msg);
	}
}
