package com.sanket.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "doctors")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Doctor {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_table")
	@SequenceGenerator(
			name = "id_table",
			sequenceName = "id_sequence",
			allocationSize = 1
	)
	private Integer doctorId;

	@Pattern(regexp = "^[0-9]{10}$", message = "Please enter a valid mobile number")
	private String mobileNo;

	private String password;

	private String name;

	@Enumerated(EnumType.STRING)
	@Column(length = 20) // Adjust the length as needed
	private City city;

	@Enumerated(EnumType.STRING)
	@Column(length = 20) // Adjust the length as needed
	private Speciality speciality;

	@Column(name = "insurance")
	private Boolean insuranceAcceptance;

	private String education;

	private String experience;

	@OneToMany(cascade = CascadeType.ALL)
	@JsonIgnore
	List<Appointment> listOfAppointments = new ArrayList<>();

	@Column(name = "from")
	private Integer appointmentFromTime;

	@Column(name = "to")
	private Integer appointmentToTime;

	// For checking if this is a doctor or patient
	private String type;

	@OneToMany(cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Review> listOfReviews = new ArrayList<>();

	private String doctorImg;

	private Boolean validDoctor = true;

	@OneToMany(cascade = CascadeType.ALL)
	@JsonIgnore
	List<Message> listOfMessage = new ArrayList<>();

	public Speciality getSpecialty() {
		return this.speciality;
	}


	// Enum for City
	public enum City {
		DELHI, NOIDA, FARIDABAD
	}

	// Enum for Speciality
	public enum Speciality {
		ORTHOPEDIC, GYNECOLOGY, DERMATOLOGY, ENT_SPECIALIST
	}

}
