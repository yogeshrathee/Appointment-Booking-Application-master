package com.sanket.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sanket.entity.Message;
import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "patients")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_table")
	@SequenceGenerator(name = "id_table", sequenceName = "id_sequence", allocationSize = 1)
	private Integer patientId;

	private String name;

	@Pattern(regexp = "^[0-9]{10}$", message = "Please enter a valid mobile number")
	private String mobileNo;

	private String password;

	@Email(message = "Email should be a valid email")
	private String email;

	private String type;

	private String city; // Add the 'city' attribute

	@Enumerated(EnumType.STRING)
	@Column(length = 20) // Adjust the length as needed
	private Symptom symptom; // Add the 'symptom' attribute

	@OneToMany(cascade = CascadeType.ALL)
	@JsonIgnore
	List<Appointment> listOfAppointments = new ArrayList<>();

	@OneToMany(cascade = CascadeType.ALL)
	@JsonIgnore
	List<Review> listReviews = new ArrayList<>();

	@OneToMany(cascade = CascadeType.ALL)
	@JsonIgnore
	List<Message> listOfMessage = new ArrayList<>();

	public String getLocation() {
		return city;
	}


	// Enum for Symptom
	@Getter
	public enum Symptom {
		ARTHRITIS("Orthopedic"),
		BACK_PAIN("Orthopedic"),
		TISSUE_INJURIES("Orthopedic"),
		DYSMENORRHEA("Gynecology"),
		SKIN_INFECTION("Dermatology"),
		SKIN_BURN("Dermatology"),
		EAR_PAIN("ENT");

		private final String speciality;

		Symptom(String speciality) {
			this.speciality = speciality;
		}

	}
}
