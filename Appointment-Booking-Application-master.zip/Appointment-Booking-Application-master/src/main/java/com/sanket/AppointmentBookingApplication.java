package com.sanket;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppointmentBookingApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(AppointmentBookingApplication.class, args);
		
	}
	
}
